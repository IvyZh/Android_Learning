package com.ivy.logindemo;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText etUserName, etPwd;
    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUserName = (EditText) findViewById(R.id.editText);
        etPwd = (EditText) findViewById(R.id.editText2);
        dialog = new ProgressDialog(this);
    }


    public void login(View v) {
        final String userName = etUserName.getText().toString().trim();
        final String pwd = etPwd.getText().toString().trim();
        boolean isLegal = checkIsLegal(userName, pwd);//检查输入的合法性
        if (isLegal) {
            dialog.show();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    SystemClock.sleep(3000);
                    if ("Ivy".equals(userName) && "123".equals(pwd)) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                dialog.dismiss();
                                Toast.makeText(MainActivity.this, "登陆成功：" + userName, Toast.LENGTH_LONG).show();

                            }
                        });
                    } else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                dialog.dismiss();
                                Toast.makeText(MainActivity.this, "用户名或密码失败", Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                }
            }).start();
        } else {
            Toast.makeText(this, "用户名或密码不能为空", Toast.LENGTH_LONG).show();
        }
    }

    private boolean checkIsLegal(String name, String pwd) {
        return !TextUtils.isEmpty(name) && !TextUtils.isEmpty(pwd);//简单的判断非空判断
    }
}

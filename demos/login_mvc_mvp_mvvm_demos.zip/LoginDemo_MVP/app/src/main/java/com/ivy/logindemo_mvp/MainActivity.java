package com.ivy.logindemo_mvp;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.ivy.logindemo_mvp.domain.User;
import com.ivy.logindemo_mvp.presenter.IUserLoginView;
import com.ivy.logindemo_mvp.presenter.UserLoginPresenter;


public class MainActivity extends AppCompatActivity implements IUserLoginView {

    private EditText etUserName, etPwd;
    private ProgressDialog dialog;
    private String userName, pwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUserName = (EditText) findViewById(R.id.editText);
        etPwd = (EditText) findViewById(R.id.editText2);
        dialog = new ProgressDialog(this);
    }


    public void login(View v) {
        userName = etUserName.getText().toString().trim();
        pwd = etPwd.getText().toString().trim();
        User user = new User(userName, pwd);

        UserLoginPresenter presenter = new UserLoginPresenter(this);
        boolean isLegal = presenter.checkIsLegal(user);
        if (isLegal) {
            dialog.show();
            presenter.login(user);
        } else {
            Toast.makeText(this, "用户名或密码不能为空", Toast.LENGTH_LONG).show();
        }
    }


    public void success() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                dialog.dismiss();
                Toast.makeText(MainActivity.this, "登陆成功：" + userName, Toast.LENGTH_LONG).show();
            }
        });
    }

    public void failed() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                dialog.dismiss();
                Toast.makeText(MainActivity.this, "用户名或密码失败", Toast.LENGTH_LONG).show();
            }
        });
    }
}

package com.ivy.logindemo_mvp.net;

import android.os.SystemClock;

import com.ivy.logindemo_mvp.domain.User;


/**
 * Created by Ivy on 2016/12/2.
 *
 * @description:
 */

public class UserLoginNet {

    public boolean sendUserLogin(User user) {
        SystemClock.sleep(3000);
        if ("Ivy".equals(user.getUserName()) && "123".equals(user.getPwd())) {
            return true;
        } else {
            return false;
        }
    }
}

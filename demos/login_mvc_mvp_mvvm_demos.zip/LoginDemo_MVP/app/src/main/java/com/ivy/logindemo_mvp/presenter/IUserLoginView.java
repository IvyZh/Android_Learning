package com.ivy.logindemo_mvp.presenter;

/**
 * Created by Ivy on 2016/12/2.
 *
 * @description:
 */

public interface IUserLoginView {
    void success();

    void failed();
}

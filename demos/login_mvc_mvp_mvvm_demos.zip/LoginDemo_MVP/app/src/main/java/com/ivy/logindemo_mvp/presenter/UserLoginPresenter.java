package com.ivy.logindemo_mvp.presenter;

import android.text.TextUtils;

import com.ivy.logindemo_mvp.domain.User;
import com.ivy.logindemo_mvp.net.UserLoginNet;

/**
 * Created by Ivy on 2016/12/2.
 *
 * @description:
 */

public class UserLoginPresenter {
    private IUserLoginView view;

    public UserLoginPresenter(IUserLoginView view) {
        //作为View可以是MainActivity也可以是Fragment，所以为了通用性，这里的思路是：放置参数为通用（抽象类或接口，实际开发中接口更通用）
        this.view = view;
    }

    public boolean checkIsLegal(User user) {
        return !TextUtils.isEmpty(user.getUserName()) && !TextUtils.isEmpty(user.getPwd());//简单的判断非空判断
    }

    public void login(final User user) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                UserLoginNet net = new UserLoginNet();
                boolean success = net.sendUserLogin(user);
                if (success) {
                    view.success();
                } else {
                    view.failed();
                }
            }
        }).start();
    }
}

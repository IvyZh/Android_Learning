package com.ivy.logindemo_mvvm;

import android.app.ProgressDialog;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.ivy.logindemo_mvvm.databinding.ActivityMainBinding;
import com.ivy.logindemo_mvvm.domain.User;
import com.ivy.logindemo_mvvm.net.UserLoginNet;

public class MainActivity extends AppCompatActivity {

    private User user;
    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityMainBinding binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        user = new User();
        user.userName.set("wangcai");
        user.pwd.set("wangcai");
        binding.setUser(user);
        binding.setEvent(new UserEvent(user));
        dialog = new ProgressDialog(this);


        new Thread(new Runnable() {
            @Override
            public void run() {
                SystemClock.sleep(3000);
                user.userName.set("xiaoqiang");
                user.pwd.set("xiaoqiang");
            }
        }).start();

    }

    public void login(View v) {
        final String userName = user.userName.get().trim();
        final String pwd = user.pwd.get().trim();

        Log.v("MVVM", userName + "," + pwd);

        boolean isLegal = checkIsLegal(userName, pwd);//检查输入的合法性
        if (isLegal) {
            dialog.show();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    UserLoginNet net = new UserLoginNet();
                    boolean success = net.sendUserLogin(user);
                    if (success) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                dialog.dismiss();
                                Toast.makeText(MainActivity.this, "登陆成功：" + userName, Toast.LENGTH_LONG).show();

                            }
                        });
                    } else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                dialog.dismiss();
                                Toast.makeText(MainActivity.this, "用户名或密码失败", Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                }
            }).start();
        } else {
            Toast.makeText(this, "用户名或密码不能为空", Toast.LENGTH_LONG).show();
        }
    }

    private boolean checkIsLegal(String name, String pwd) {
        return !TextUtils.isEmpty(name) && !TextUtils.isEmpty(pwd);//简单的判断非空判断
    }
}

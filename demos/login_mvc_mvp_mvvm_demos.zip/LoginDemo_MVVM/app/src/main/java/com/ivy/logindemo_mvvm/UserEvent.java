package com.ivy.logindemo_mvvm;

import android.text.Editable;
import android.text.TextWatcher;

import com.ivy.logindemo_mvvm.domain.User;

/**
 * Created by Ivy on 2016/12/2.
 *
 * @description:
 */

public class UserEvent {

    private User mUser;

    public UserEvent(User user) {
        mUser = user;
    }

    public TextWatcher userNameWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence sequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence sequence, int i, int i1, int i2) {

        }

        @Override
        public void afterTextChanged(Editable editable) {
            mUser.userName.set(editable.toString());
        }
    };

    public TextWatcher pwdWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence sequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence sequence, int i, int i1, int i2) {

        }

        @Override
        public void afterTextChanged(Editable editable) {
            mUser.pwd.set(editable.toString());
        }
    };

}

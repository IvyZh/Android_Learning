package com.ivy.logindemo_mvvm.domain;

import android.databinding.ObservableField;

/**
 * Created by Ivy on 2016/12/2.
 *
 * @description:
 */

public class User {
    public final ObservableField<String> userName = new ObservableField<>();
    public final ObservableField<String> pwd = new ObservableField<>();
}

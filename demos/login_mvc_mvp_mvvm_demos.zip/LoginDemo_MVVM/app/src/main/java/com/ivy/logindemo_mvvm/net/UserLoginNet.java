package com.ivy.logindemo_mvvm.net;

import android.os.SystemClock;

import com.ivy.logindemo_mvvm.domain.User;


/**
 * Created by Ivy on 2016/12/2.
 *
 * @description:
 */

public class UserLoginNet {

    public boolean sendUserLogin(User user) {
        SystemClock.sleep(3000);
        if ("Ivy".equals(user.userName.get()) && "123".equals(user.pwd.get())) {
            return true;
        } else {
            return false;
        }
    }
}
